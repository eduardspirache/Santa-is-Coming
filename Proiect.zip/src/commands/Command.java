package commands;

public interface Command {
    /**
     * Interface for command pattern
     */
    void execute();
}
